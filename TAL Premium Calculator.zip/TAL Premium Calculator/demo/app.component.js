"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var AppComponent = (function () {
    function AppComponent() {
        this.MaxRangeDate = new Date();
    }
    AppComponent.prototype.formatDate = function (date) {
        return date.toLocaleString();
    };
    AppComponent.prototype.onSelect = function (date) {
        console.log("onSelect: ", date);
    };
    AppComponent.prototype.calculate = function () {
        if (this.Name == undefined || this.date == undefined || this.gender == undefined) {
            alert('Please enter/select required fields');
        }
        else {
            var timeDiff = Math.abs(Date.now() - this.date);
            var age = Math.floor((timeDiff / (1000 * 3600 * 24)) / 365);
            if (age > 18 && age < 65) {
                this.premium = age * this.gender * 100;
                alert(this.premium);
            }
            else {
                alert('The person can only receive a Premium if they are between the age of 18 and 65');
            }
        }
    };
    __decorate([
        core_1.Input(),
        __metadata("design:type", Date)
    ], AppComponent.prototype, "MaxRangeDate", void 0);
    AppComponent = __decorate([
        core_1.Component({
            selector: 'my-app',
            template: "\n\n  <h1> TAL premium calculator</h1>\n\n   <div class=\"table\">\n   <div class=\"tr\">\n     <div class=\"td\">Enter Name:</div>\n     <div class=\"td\"> <input type=\"text\" [(ngModel)]=\"Name\" style=\"width:100%\"/></div>    \n   </div>\n   <div class=\"tr\">\n     <div class=\"td\">Enter Date of Birth:</div>\n     <div class=\"td\"><material-datepicker\n     [(date)]=\"date\"\n     (onSelect)=\"onSelect($event)\"\n     [rangeEnd]=\"MaxRangeDate\"\n     dateFormat=\"DD-MM-YYYY\" ></material-datepicker> </div>    \n   </div>\n    <div class=\"tr\">\n     <div class=\"td\">Select Gender:</div>\n     <div class=\"td\"><select [(ngModel)]=\"gender\" (input)=\"onInput($event)\" style=\"width:100%\" >\n     <option  value='1.2' >Male</option>\n     <option  value='1.1'>Female</option>\n     </select>    </div>    \n   </div>\n   <div class=\"tr\"> \n   <div class=\"td\"></div>\n     <div class=\"td\">  <button (click)=\"calculate()\">Calculate</button></div>     \n </div>  \n    ",
            styles: ["\n    div.table {display: table; }\n    div.tr {display: table-row;height:30px }\n    div.td {display: table-cell; }\n    \n    "]
        }),
        __metadata("design:paramtypes", [])
    ], AppComponent);
    return AppComponent;
}());
exports.AppComponent = AppComponent;
//# sourceMappingURL=app.component.js.map