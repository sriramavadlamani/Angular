import { Component, Input } from '@angular/core';

@Component({
  selector: 'my-app',
  template: `

  <h1> TAL premium calculator</h1>

   <div class="table">
   <div class="tr">
     <div class="td">Enter Name:</div>
     <div class="td"> <input type="text" [(ngModel)]="Name" style="width:100%"/></div>    
   </div>
   <div class="tr">
     <div class="td">Enter Date of Birth:</div>
     <div class="td"><material-datepicker
     [(date)]="date"
     (onSelect)="onSelect($event)"
     [rangeEnd]="MaxRangeDate"
     dateFormat="DD-MM-YYYY" ></material-datepicker> </div>    
   </div>
    <div class="tr">
     <div class="td">Select Gender:</div>
     <div class="td"><select [(ngModel)]="gender" (input)="onInput($event)" style="width:100%" >
     <option  value='1.2' >Male</option>
     <option  value='1.1'>Female</option>
     </select>    </div>    
   </div>
   <div class="tr"> 
   <div class="td"></div>
     <div class="td">  <button (click)="calculate()">Calculate</button></div>     
 </div>  
    `,
    styles: [`
    div.table {display: table; }
    div.tr {display: table-row;height:30px }
    div.td {display: table-cell; }
    
    `]
   
})
export class AppComponent {
  date: any;
  disabled: boolean;
  premium:any;
  gender:any;
  Name:any;
  @Input() MaxRangeDate: Date;

  constructor() {
    this.MaxRangeDate = new Date();
  }

  formatDate(date: Date): string {
    return date.toLocaleString();
  }

  onSelect(date: Date) {
    console.log("onSelect: ", date);
  }
  calculate(){     
     if(this.Name==undefined ||this.date==undefined ||this.gender==undefined ){
       alert('Please enter/select required fields');
     }else{
      var timeDiff = Math.abs(Date.now() - this.date);     
      let age = Math.floor((timeDiff / (1000 * 3600 * 24))/365);
      if(age>18 && age<65){
        this.premium=age*this.gender*100;
        alert(this.premium);
      }else{
        alert('The person can only receive a Premium if they are between the age of 18 and 65');
      }   
     } 
      
  } 
}
