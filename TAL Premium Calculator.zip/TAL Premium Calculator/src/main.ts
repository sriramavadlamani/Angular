import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';

import { DatepickerModule } from './datepicker.module';

platformBrowserDynamic().bootstrapModule(DatepickerModule);
