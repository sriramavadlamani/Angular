"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var platform_browser_dynamic_1 = require("@angular/platform-browser-dynamic");
var datepicker_module_1 = require("./datepicker.module");
platform_browser_dynamic_1.platformBrowserDynamic().bootstrapModule(datepicker_module_1.DatepickerModule);
//# sourceMappingURL=main.js.map